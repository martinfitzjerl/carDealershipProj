package com.claim.controller;

import java.util.ArrayList;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import com.claim.entity.User;


@Controller
public class UserController {
	
	@Autowired
	UserService userSrv;
	
	
	@GetMapping("/")
	public String welcome(Model model) {
		
		return "index";
	}
	
	@PostMapping("/sign-up")
	public String handleSignUp(Model model, 
			@ModelAttribute("user") User user, HttpSession 
			session) { 
		model.addAttribute("newStudent", user);
			userSrv.saveUser(user);
		return "thank-you";
	}

	
	@GetMapping("/sign-up")
    public ModelAndView signUp(Model model) {
		return new ModelAndView("sign-up", "user", new User()); 
	}
	
	
	@PostMapping("/login")
	public String handleLogin(Model model, 
			@ModelAttribute("user") User user, HttpSession 
			session) { model.addAttribute("newUser", user);
			userSrv.saveUser(user);
			User tempUser = userSrv.handleLogin(user);
			if(tempUser == null) {
				model.addAttribute("error", "Invalid login");
				return "login";
				
			}else
			{
				model.addAttribute("loginUser", tempUser);
				return "home";
			}

	}

	
	@GetMapping("/login")
    public ModelAndView login(Model model) {
		return new ModelAndView("sign-up", "student", new User()); 
	}
	
	@GetMapping("/home")
	public String home(Model model) {
		model.addAttribute("listUser", userSrv.getUsers());
		return "userList";
	}
	
	@GetMapping("/userList")
	public String userList(Model model) {
		
		ArrayList<User> userList = userSrv.getUserList();
		
		model.addAttribute("userList", userList);
		
		return "userList";

	}
	
	



}
